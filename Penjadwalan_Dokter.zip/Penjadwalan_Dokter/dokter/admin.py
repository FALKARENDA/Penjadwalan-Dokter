from django.contrib import admin
from .models import Specialization, DoctorProfile, Schedule


@admin.register(Specialization)
class SpecializationAdmin(admin.ModelAdmin):
    list_display = ('name', 'description', 'created_at')
    search_fields = ('name',)
    list_filter = ('created_at',)


class ScheduleInline(admin.TabularInline):
    model = Schedule
    extra = 1
    fields = ('weekday', 'start_time', 'end_time', 'is_active')


@admin.register(DoctorProfile)
class DoctorProfileAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'specialization', 'phone',
                    'experience_years', 'consultation_fee', 'is_available')
    list_filter = ('specialization', 'is_available', 'experience_years')
    search_fields = ('full_name', 'license_number', 'user__username')
    readonly_fields = ('created_at', 'updated_at')
    inlines = [ScheduleInline]

    fieldsets = (
        ('Informasi Dasar', {
            'fields': ('user', 'full_name', 'specialization')
        }),
        ('Kontak & Lisensi', {
            'fields': ('phone', 'license_number')
        }),
        ('Profesional Info', {
            'fields': ('experience_years', 'consultation_fee', 'bio')
        }),
        ('Status', {
            'fields': ('is_available',)
        }),
        ('Timestamp', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )


@admin.register(Schedule)
class ScheduleAdmin(admin.ModelAdmin):
    list_display = ('doctor', 'get_weekday_display',
                    'start_time', 'end_time', 'is_active')
    list_filter = ('weekday', 'is_active', 'doctor__specialization')
    search_fields = ('doctor__full_name',)
    ordering = ('doctor', 'weekday', 'start_time')
