from django.contrib import admin
from .models import PatientProfile


@admin.register(PatientProfile)
class PatientProfileAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'phone', 'gender',
                    'blood_type', 'date_of_birth')
    list_filter = ('gender', 'blood_type', 'created_at')
    search_fields = ('full_name', 'phone', 'user__username')
    readonly_fields = ('created_at', 'updated_at')

    fieldsets = (
        ('Informasi Dasar', {
            'fields': ('user', 'full_name', 'phone')
        }),
        ('Data Pribadi', {
            'fields': ('date_of_birth', 'gender', 'blood_type', 'address')
        }),
        ('Kontak Darurat', {
            'fields': ('emergency_contact',)
        }),
        ('Riwayat Medis', {
            'fields': ('medical_history', 'allergies'),
            'classes': ('collapse',)
        }),
        ('Timestamp', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
