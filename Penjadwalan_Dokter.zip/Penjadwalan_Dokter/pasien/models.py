from django.db import models
from django.utils import timezone
from accounts.models import User


class PatientProfile(models.Model):
    GENDER_CHOICES = [
        ('L', 'Laki-laki'),
        ('P', 'Perempuan'),
    ]

    BLOOD_TYPE_CHOICES = [
        ('A', 'A'),
        ('B', 'B'),
        ('AB', 'AB'),
        ('O', 'O'),
    ]

    user = models.OneToOneField(
        User, on_delete=models.CASCADE, limit_choices_to={'role': 'pasien'})
    full_name = models.CharField(max_length=100)
    phone = models.CharField(max_length=20)
    address = models.TextField(blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, blank=True)
    blood_type = models.CharField(
        max_length=2, choices=BLOOD_TYPE_CHOICES, blank=True)
    emergency_contact = models.CharField(
        max_length=20, blank=True, help_text="Kontak darurat")
    medical_history = models.TextField(
        blank=True, null=True, help_text="Riwayat penyakit")
    allergies = models.TextField(
        blank=True, null=True, help_text="Alergi yang dimiliki")
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.full_name

    class Meta:
        ordering = ['full_name']
