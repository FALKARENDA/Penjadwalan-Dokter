from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django import forms
from .models import User


class CustomUserCreationForm(UserCreationForm):
    role = forms.ChoiceField(
        choices=[('', '-- Pilih Role --')] + list(User.ROLE_CHOICES),
        required=False,
        help_text='Pilih role untuk user ini.'
    )

    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name', 'role')

    def save(self, commit=True):
        user = super().save(commit=False)
        role = self.cleaned_data.get('role')
        if role:
            user.role = role
        if commit:
            user.save()
        return user


class CustomUserChangeForm(UserChangeForm):
    role = forms.ChoiceField(
        choices=[('', '-- Tidak ada role --')] + list(User.ROLE_CHOICES),
        required=False,
        help_text='Role user dalam sistem.'
    )

    class Meta:
        model = User
        fields = '__all__'


class UserAdmin(BaseUserAdmin):
    form = CustomUserChangeForm
    add_form = CustomUserCreationForm

    # Tampilan list di admin
    list_display = ('username', 'email', 'first_name',
                    'last_name', 'role', 'is_staff', 'is_active')
    list_filter = ('role', 'is_staff', 'is_superuser', 'is_active')
    search_fields = ('username', 'first_name', 'last_name', 'email')
    ordering = ('username',)

    # Form untuk edit user
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Role Information', {'fields': ('role',)}),
    )

    # Form untuk add user
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'password1', 'password2'),
        }),
        ('Personal info', {
            'fields': ('first_name', 'last_name', 'email')
        }),
        ('Role', {
            'fields': ('role',)
        }),
        ('Permissions', {
            'fields': ('is_active', 'is_staff', 'is_superuser')
        }),
    )

    # Actions
    actions = ['make_dokter', 'make_pasien']

    def make_dokter(self, request, queryset):
        queryset.update(role='dokter')
        self.message_user(
            request, f'{queryset.count()} user berhasil diubah menjadi dokter.')
    make_dokter.short_description = "Jadikan sebagai Dokter"

    def make_pasien(self, request, queryset):
        queryset.update(role='pasien')
        self.message_user(
            request, f'{queryset.count()} user berhasil diubah menjadi pasien.')
    make_pasien.short_description = "Jadikan sebagai Pasien"


admin.site.register(User, UserAdmin)

# Customize admin site
admin.site.site_header = "Penjadwalan Dokter Admin"
admin.site.site_title = "Penjadwalan Dokter Admin Portal"
admin.site.index_title = "Selamat datang di Penjadwalan Dokter Administration"
