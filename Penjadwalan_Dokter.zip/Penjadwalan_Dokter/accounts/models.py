from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    ROLE_CHOICES = (
        ('pasien', 'Pasien'),
        ('dokter', 'Dokter'),
    )
    role = models.CharField(
        max_length=10, choices=ROLE_CHOICES, blank=True, null=True)

    def __str__(self):
        if self.is_staff or self.is_superuser:
            return f"{self.username} (Admin)"
        elif self.role:
            return f"{self.username} ({self.get_role_display()})"
        else:
            return self.username
