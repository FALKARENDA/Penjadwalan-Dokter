from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import get_user_model
from django import forms
from dokter.models import DoctorProfile, Specialization, Schedule
from pasien.models import PatientProfile

User = get_user_model()


class UserRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)
    password_confirm = forms.CharField(
        widget=forms.PasswordInput, label='Konfirmasi Password')

    class Meta:
        model = User
        fields = ['username', 'email', 'first_name', 'last_name', 'password']

    def clean_password_confirm(self):
        password = self.cleaned_data.get('password')
        password_confirm = self.cleaned_data.get('password_confirm')

        if password and password_confirm and password != password_confirm:
            raise forms.ValidationError('Password tidak cocok')
        return password_confirm

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])
        user.role = 'pasien'  # Otomatis set sebagai pasien
        if commit:
            user.save()
            # Buat PatientProfile otomatis
            PatientProfile.objects.create(
                user=user,
                full_name=f"{user.first_name} {user.last_name}".strip(
                ) or user.username,
                phone="",
            )
        return user


class DoctorProfileForm(forms.ModelForm):
    class Meta:
        model = DoctorProfile
        fields = ['full_name', 'specialization', 'phone', 'bio', 'license_number',
                  'experience_years', 'consultation_fee', 'is_available']
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 4}),
            'consultation_fee': forms.NumberInput(attrs={'step': '0.01'}),
        }


class PatientProfileForm(forms.ModelForm):
    class Meta:
        model = PatientProfile
        fields = ['full_name', 'phone', 'address', 'date_of_birth', 'gender',
                  'blood_type', 'emergency_contact', 'medical_history', 'allergies']
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
            'address': forms.Textarea(attrs={'rows': 3}),
            'medical_history': forms.Textarea(attrs={'rows': 3}),
            'allergies': forms.Textarea(attrs={'rows': 2}),
        }


class ScheduleForm(forms.ModelForm):
    class Meta:
        model = Schedule
        fields = ['weekday', 'start_time', 'end_time', 'is_active']
        widgets = {
            'start_time': forms.TimeInput(attrs={'type': 'time'}),
            'end_time': forms.TimeInput(attrs={'type': 'time'}),
        }


def login_view(request):
    if request.user.is_authenticated:
        # Jika user adalah admin/superuser, redirect ke admin
        if request.user.is_staff or request.user.is_superuser:
            return redirect('/admin/')
        return redirect('dashboard')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                # Jika user adalah admin/superuser, redirect ke admin
                if user.is_staff or user.is_superuser:
                    messages.success(
                        request, f'Selamat datang Admin, {user.username}!')
                    return redirect('/admin/')
                else:
                    messages.success(
                        request, f'Selamat datang, {user.first_name or user.username}!')
                    return redirect('dashboard')
            else:
                messages.error(request, 'Username atau password salah.')
        else:
            messages.error(request, 'Form tidak valid.')
    else:
        form = AuthenticationForm()

    return render(request, 'accounts/login.html', {'form': form})


def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, 'Registrasi berhasil! Silakan login.')
            return redirect('login')
        else:
            messages.error(request, 'Terjadi kesalahan dalam registrasi.')
    else:
        form = UserRegistrationForm()

    return render(request, 'accounts/register.html', {'form': form})


@login_required
def logout_view(request):
    logout(request)
    messages.info(request, 'Anda telah logout.')
    return redirect('login')


@login_required
def dashboard_view(request):
    from booking.models import Booking
    from django.utils import timezone
    from datetime import timedelta

    context = {'user': request.user}

    # Add notification count to context - temporarily disabled until migration is fixed
    try:
        from booking.models import Notification
        from booking.utils import get_unread_notifications_count
        context['unread_notification_count'] = get_unread_notifications_count(
            request.user)
    except Exception:
        # Fallback if notification table doesn't exist yet
        context['unread_notification_count'] = 0

    # Get profile data based on role
    if request.user.role == 'dokter':
        try:
            doctor_profile = DoctorProfile.objects.get(user=request.user)
            context['doctor_profile'] = doctor_profile
            context['schedules'] = doctor_profile.schedules.filter(
                is_active=True)

            # Get doctor statistics
            today = timezone.now().date()
            this_month = timezone.now().replace(day=1).date()

            doctor_bookings = Booking.objects.filter(doctor=doctor_profile)

            context['stats'] = {
                'total_patients': doctor_bookings.values('patient').distinct().count(),
                'today_bookings': doctor_bookings.filter(
                    booking_date=today,
                    status__in=['pending', 'confirmed']
                ).count(),
                'monthly_consultations': doctor_bookings.filter(
                    booking_date__gte=this_month,
                    status='completed'
                ).count(),
                'pending_bookings': doctor_bookings.filter(status='pending').count(),
            }

            # Get recent bookings for doctor
            context['recent_bookings'] = doctor_bookings.select_related(
                'patient', 'patient__user'
            ).order_by('-created_at')[:5]

            # Get today's schedule
            today_weekday = today.weekday()
            context['today_schedules'] = Schedule.objects.filter(
                doctor=doctor_profile,
                weekday=today_weekday,
                is_active=True
            ).order_by('start_time')
        except DoctorProfile.DoesNotExist:
            context['doctor_profile'] = None

    elif request.user.role == 'pasien':
        try:
            patient_profile = PatientProfile.objects.get(user=request.user)
            context['patient_profile'] = patient_profile

            # Get patient statistics
            patient_bookings = Booking.objects.filter(patient=patient_profile)

            context['stats'] = {
                'active_bookings': patient_bookings.filter(
                    status__in=['pending', 'confirmed']
                ).count(),
                'completed_bookings': patient_bookings.filter(
                    status='completed'
                ).count(),
                'pending_bookings': patient_bookings.filter(
                    status='pending'
                ).count(),
                'total_bookings': patient_bookings.count(),
            }

            # Get recent bookings for patient
            context['recent_bookings'] = patient_bookings.select_related(
                'doctor', 'doctor__specialization'
            ).order_by('-created_at')[:5]

            # Get upcoming appointments
            today = timezone.now().date()
            context['upcoming_appointments'] = patient_bookings.filter(
                booking_date__gte=today,
                status__in=['pending', 'confirmed']
            ).select_related(
                'doctor', 'doctor__specialization', 'schedule'
            ).order_by('booking_date')[:3]
        except PatientProfile.DoesNotExist:
            context['patient_profile'] = None

    return render(request, 'accounts/dashboard.html', context)


@login_required
def profile_view(request):
    if request.user.role == 'dokter':
        return redirect('doctor_profile')
    elif request.user.role == 'pasien':
        return redirect('patient_profile')
    else:
        messages.error(request, 'Role tidak dikenali.')
        return redirect('dashboard')


@login_required
def doctor_profile_view(request):
    if request.user.role != 'dokter':
        messages.error(request, 'Akses ditolak. Anda bukan dokter.')
        return redirect('dashboard')

    try:
        doctor_profile = DoctorProfile.objects.get(user=request.user)
    except DoctorProfile.DoesNotExist:
        doctor_profile = None

    if request.method == 'POST':
        if doctor_profile:
            form = DoctorProfileForm(request.POST, instance=doctor_profile)
        else:
            form = DoctorProfileForm(request.POST)

        if form.is_valid():
            profile = form.save(commit=False)
            profile.user = request.user
            profile.save()
            messages.success(request, 'Profile berhasil diperbarui!')
            return redirect('doctor_profile')
    else:
        form = DoctorProfileForm(instance=doctor_profile)

    schedules = Schedule.objects.filter(
        doctor=doctor_profile) if doctor_profile else []

    return render(request, 'accounts/doctor_profile.html', {
        'form': form,
        'doctor_profile': doctor_profile,
        'schedules': schedules
    })


@login_required
def patient_profile_view(request):
    if request.user.role != 'pasien':
        messages.error(request, 'Akses ditolak. Anda bukan pasien.')
        return redirect('dashboard')

    try:
        patient_profile = PatientProfile.objects.get(user=request.user)
    except PatientProfile.DoesNotExist:
        patient_profile = None

    if request.method == 'POST':
        if patient_profile:
            form = PatientProfileForm(request.POST, instance=patient_profile)
        else:
            form = PatientProfileForm(request.POST)

        if form.is_valid():
            profile = form.save(commit=False)
            profile.user = request.user
            profile.save()
            messages.success(request, 'Profile berhasil diperbarui!')
            return redirect('patient_profile')
    else:
        form = PatientProfileForm(instance=patient_profile)

    return render(request, 'accounts/patient_profile.html', {
        'form': form,
        'patient_profile': patient_profile
    })


@login_required
def manage_schedule_view(request):
    if request.user.role != 'dokter':
        messages.error(request, 'Akses ditolak. Anda bukan dokter.')
        return redirect('dashboard')

    try:
        doctor_profile = DoctorProfile.objects.get(user=request.user)
    except DoctorProfile.DoesNotExist:
        messages.error(
            request, 'Profile dokter tidak ditemukan. Silakan lengkapi profile terlebih dahulu.')
        return redirect('doctor_profile')

    if request.method == 'POST':
        form = ScheduleForm(request.POST)
        if form.is_valid():
            schedule = form.save(commit=False)
            schedule.doctor = doctor_profile
            schedule.save()
            messages.success(request, 'Jadwal berhasil ditambahkan!')
            return redirect('manage_schedule')
    else:
        form = ScheduleForm()

    schedules = Schedule.objects.filter(
        doctor=doctor_profile).order_by('weekday', 'start_time')

    return render(request, 'accounts/manage_schedule.html', {
        'form': form,
        'schedules': schedules,
        'doctor_profile': doctor_profile
    })


@login_required
def delete_schedule_view(request, schedule_id):
    if request.user.role != 'dokter':
        messages.error(request, 'Akses ditolak.')
        return redirect('dashboard')

    try:
        doctor_profile = DoctorProfile.objects.get(user=request.user)
        schedule = get_object_or_404(
            Schedule, id=schedule_id, doctor=doctor_profile)
        schedule.delete()
        messages.success(request, 'Jadwal berhasil dihapus!')
    except DoctorProfile.DoesNotExist:
        messages.error(request, 'Profile dokter tidak ditemukan.')

    return redirect('manage_schedule')
