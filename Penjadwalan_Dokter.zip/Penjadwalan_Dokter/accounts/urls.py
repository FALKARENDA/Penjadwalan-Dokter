from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('profile/', views.profile_view, name='profile'),
    path('profile/doctor/', views.doctor_profile_view, name='doctor_profile'),
    path('profile/patient/', views.patient_profile_view, name='patient_profile'),
    path('schedule/manage/', views.manage_schedule_view, name='manage_schedule'),
    path('schedule/delete/<int:schedule_id>/',
         views.delete_schedule_view, name='delete_schedule'),
]
