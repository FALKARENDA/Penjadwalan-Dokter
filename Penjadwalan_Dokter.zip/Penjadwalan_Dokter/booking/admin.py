from django.contrib import admin
from .models import Booking, BookingHistory


class BookingHistoryInline(admin.TabularInline):
    model = BookingHistory
    extra = 0
    readonly_fields = ('old_status', 'new_status', 'changed_by', 'created_at')
    can_delete = False


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('patient', 'doctor', 'booking_date',
                    'status', 'created_at')
    list_filter = ('status', 'booking_date',
                   'doctor__specialization', 'created_at')
    search_fields = ('patient__full_name', 'doctor__full_name', 'complaint')
    readonly_fields = ('created_at', 'updated_at')
    inlines = [BookingHistoryInline]

    fieldsets = (
        ('Informasi Booking', {
            'fields': ('patient', 'doctor', 'schedule', 'booking_date')
        }),
        ('Detail Konsultasi', {
            'fields': ('complaint', 'notes', 'doctor_notes')
        }),
        ('Status', {
            'fields': ('status',)
        }),
        ('Timestamp', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def save_model(self, request, obj, form, change):
        if change and 'status' in form.changed_data:
            # Simpan history perubahan status
            old_obj = Booking.objects.get(pk=obj.pk)
            BookingHistory.objects.create(
                booking=obj,
                old_status=old_obj.status,
                new_status=obj.status,
                changed_by=request.user,
                notes=f"Status diubah oleh {request.user.username}"
            )
        super().save_model(request, obj, form, change)


@admin.register(BookingHistory)
class BookingHistoryAdmin(admin.ModelAdmin):
    list_display = ('booking', 'old_status', 'new_status',
                    'changed_by', 'created_at')
    list_filter = ('old_status', 'new_status', 'created_at')
    readonly_fields = ('booking', 'old_status', 'new_status',
                       'changed_by', 'created_at')

    def has_add_permission(self, request):
        return False
