from django.db import models
from django.utils import timezone
from django.core.exceptions import ValidationError
from accounts.models import User
from dokter.models import DoctorProfile, Schedule
from pasien.models import PatientProfile


class Booking(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Menunggu Konfirmasi'),
        ('confirmed', 'Dikonfirmasi'),
        ('completed', 'Selesai'),
        ('cancelled', 'Dibatalkan'),
        ('rejected', 'Ditolak'),
    )

    patient = models.ForeignKey(
        PatientProfile, on_delete=models.CASCADE, related_name='bookings', null=True, blank=True)
    doctor = models.ForeignKey(
        DoctorProfile, on_delete=models.CASCADE, related_name='bookings', null=True, blank=True)
    schedule = models.ForeignKey(
        Schedule, on_delete=models.CASCADE, related_name='bookings', null=True, blank=True)
    booking_date = models.DateField(
        null=True, blank=True, help_text="Tanggal booking yang diinginkan")
    complaint = models.TextField(
        null=True, blank=True, help_text="Keluhan atau gejala yang dialami")
    notes = models.TextField(blank=True, null=True,
                             help_text="Catatan tambahan dari pasien")
    status = models.CharField(
        max_length=10, choices=STATUS_CHOICES, default='pending')
    doctor_notes = models.TextField(
        blank=True, null=True, help_text="Catatan dari dokter")
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.patient.full_name} - Dr. {self.doctor.full_name} ({self.booking_date})"

    def clean(self):
        # Validasi bahwa booking date tidak boleh di masa lalu
        if self.booking_date and self.booking_date < timezone.now().date():
            raise ValidationError("Tanggal booking tidak boleh di masa lalu.")

        # Validasi bahwa schedule sesuai dengan hari booking
        if self.schedule and self.booking_date:
            weekday = self.booking_date.weekday()
            if self.schedule.weekday != weekday:
                raise ValidationError(
                    "Jadwal tidak sesuai dengan hari yang dipilih.")

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    class Meta:
        ordering = ['-created_at']
        unique_together = ['patient', 'doctor', 'booking_date', 'schedule']


class BookingHistory(models.Model):
    """Model untuk menyimpan riwayat perubahan status booking"""
    booking = models.ForeignKey(
        Booking, on_delete=models.CASCADE, related_name='history')
    old_status = models.CharField(
        max_length=10, choices=Booking.STATUS_CHOICES)
    new_status = models.CharField(
        max_length=10, choices=Booking.STATUS_CHOICES)
    changed_by = models.ForeignKey(User, on_delete=models.CASCADE)
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.booking} - {self.old_status} to {self.new_status}"

    class Meta:
        ordering = ['-created_at']


class Notification(models.Model):
    """Model untuk sistem notifikasi"""
    NOTIFICATION_TYPES = (
        ('booking_created', 'Booking Dibuat'),
        ('booking_confirmed', 'Booking Dikonfirmasi'),
        ('booking_rejected', 'Booking Ditolak'),
        ('booking_cancelled', 'Booking Dibatalkan'),
        ('booking_completed', 'Booking Selesai'),
        ('booking_reminder', 'Pengingat Booking'),
        ('schedule_updated', 'Jadwal Diperbarui'),
        ('system', 'Notifikasi Sistem'),
    )

    recipient = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=200)
    message = models.TextField()
    notification_type = models.CharField(
        max_length=20, choices=NOTIFICATION_TYPES, default='system')
    booking = models.ForeignKey(
        Booking, on_delete=models.CASCADE, null=True, blank=True,
        help_text="Booking terkait jika notifikasi berkaitan dengan booking")
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)

    # Optional: URL untuk action
    action_url = models.CharField(max_length=200, blank=True, null=True)

    def __str__(self):
        return f"{self.title} - {self.recipient.username}"

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['recipient', 'is_read']),
            models.Index(fields=['created_at']),
        ]

    def mark_as_read(self):
        """Mark notification as read"""
        self.is_read = True
        self.save(update_fields=['is_read'])
