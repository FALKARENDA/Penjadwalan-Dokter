from django.urls import path
from . import views

app_name = 'booking'

urlpatterns = [
    path('doctors/', views.doctor_list_view, name='doctor_list'),
    path('doctors/<int:doctor_id>/',
         views.doctor_detail_view, name='doctor_detail'),
    path('create/', views.create_booking_view, name='create_booking'),
    path('create/<int:doctor_id>/', views.create_booking_view,
         name='create_booking_with_doctor'),
    path('history/', views.booking_history_view, name='booking_history'),
    path('detail/<int:booking_id>/',
         views.booking_detail_view, name='booking_detail'),
    path('cancel/<int:booking_id>/',
         views.cancel_booking_view, name='cancel_booking'),
    path('success/<int:booking_id>/',
         views.booking_success_view, name='booking_success'),
    # Doctor views
    path('doctor/bookings/', views.doctor_booking_list_view,
         name='doctor_booking_list'),
    path('doctor/bookings/<int:booking_id>/',
         views.doctor_booking_detail_view, name='doctor_booking_detail'),
    # Notification views
    path('notifications/', views.notification_list_view, name='notification_list'),
    path('notifications/<int:notification_id>/read/',
         views.mark_notification_read, name='mark_notification_read'),
    path('notifications/mark-all-read/',
         views.mark_all_notifications_read, name='mark_all_notifications_read'),
    path('api/notification-count/', views.get_notification_count,
         name='notification_count'),
]
