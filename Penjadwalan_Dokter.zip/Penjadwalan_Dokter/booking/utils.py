from django.urls import reverse
from .models import Notification


def create_notification(recipient, title, message, notification_type, booking=None, action_url=None):
    """
    Helper function untuk membuat notifikasi
    """
    notification = Notification.objects.create(
        recipient=recipient,
        title=title,
        message=message,
        notification_type=notification_type,
        booking=booking,
        action_url=action_url
    )
    return notification


def create_booking_notification(booking, action, actor=None, notes=None):
    """
    Membuat notifikasi berdasarkan aksi booking
    """
    if action == 'created':
        # Notifikasi untuk dokter bahwa ada booking baru
        create_notification(
            recipient=booking.doctor.user,
            title="Booking Baru Diterima",
            message=f"Anda mendapat booking baru dari {booking.patient.full_name} untuk tanggal {booking.booking_date.strftime('%d %B %Y')}.",
            notification_type='booking_created',
            booking=booking,
            action_url=reverse(
                'booking:doctor_booking_detail', args=[booking.id])
        )

        # Notifikasi untuk pasien konfirmasi booking dibuat
        create_notification(
            recipient=booking.patient.user,
            title="Booking Berhasil Dibuat",
            message=f"Booking Anda dengan Dr. {booking.doctor.full_name} untuk tanggal {booking.booking_date.strftime('%d %B %Y')} telah dibuat dan menunggu konfirmasi.",
            notification_type='booking_created',
            booking=booking,
            action_url=reverse('booking:booking_detail', args=[booking.id])
        )

    elif action == 'confirmed':
        # Notifikasi untuk pasien bahwa booking dikonfirmasi
        create_notification(
            recipient=booking.patient.user,
            title="Booking Dikonfirmasi",
            message=f"Booking Anda dengan Dr. {booking.doctor.full_name} untuk tanggal {booking.booking_date.strftime('%d %B %Y')} telah dikonfirmasi. Silakan datang sesuai jadwal.",
            notification_type='booking_confirmed',
            booking=booking,
            action_url=reverse('booking:booking_detail', args=[booking.id])
        )

    elif action == 'rejected':
        # Notifikasi untuk pasien bahwa booking ditolak
        reject_reason = f" Alasan: {notes}" if notes else ""
        create_notification(
            recipient=booking.patient.user,
            title="Booking Ditolak",
            message=f"Mohon maaf, booking Anda dengan Dr. {booking.doctor.full_name} untuk tanggal {booking.booking_date.strftime('%d %B %Y')} ditolak.{reject_reason}",
            notification_type='booking_rejected',
            booking=booking,
            action_url=reverse('booking:booking_detail', args=[booking.id])
        )

    elif action == 'cancelled':
        # Notifikasi untuk dokter bahwa pasien membatalkan booking
        if actor and actor.role == 'pasien':
            create_notification(
                recipient=booking.doctor.user,
                title="Booking Dibatalkan Pasien",
                message=f"Booking dari {booking.patient.full_name} untuk tanggal {booking.booking_date.strftime('%d %B %Y')} telah dibatalkan oleh pasien.",
                notification_type='booking_cancelled',
                booking=booking,
                action_url=reverse(
                    'booking:doctor_booking_detail', args=[booking.id])
            )
        # Notifikasi untuk pasien bahwa dokter membatalkan booking
        elif actor and actor.role == 'dokter':
            cancel_reason = f" Alasan: {notes}" if notes else ""
            create_notification(
                recipient=booking.patient.user,
                title="Booking Dibatalkan Dokter",
                message=f"Booking Anda dengan Dr. {booking.doctor.full_name} untuk tanggal {booking.booking_date.strftime('%d %B %Y')} dibatalkan oleh dokter.{cancel_reason}",
                notification_type='booking_cancelled',
                booking=booking,
                action_url=reverse('booking:booking_detail', args=[booking.id])
            )

    elif action == 'completed':
        # Notifikasi untuk pasien bahwa konsultasi selesai
        create_notification(
            recipient=booking.patient.user,
            title="Konsultasi Selesai",
            message=f"Konsultasi Anda dengan Dr. {booking.doctor.full_name} telah selesai. Terima kasih telah menggunakan layanan kami.",
            notification_type='booking_completed',
            booking=booking,
            action_url=reverse('booking:booking_detail', args=[booking.id])
        )


def create_reminder_notifications():
    """
    Membuat notifikasi pengingat untuk booking yang akan datang
    Dapat dipanggil melalui cron job atau task scheduler
    """
    from django.utils import timezone
    from datetime import timedelta
    from .models import Booking

    tomorrow = timezone.now().date() + timedelta(days=1)

    # Booking yang akan berlangsung besok
    tomorrow_bookings = Booking.objects.filter(
        booking_date=tomorrow,
        status='confirmed'
    ).select_related('patient__user', 'doctor__user')

    for booking in tomorrow_bookings:
        # Pengingat untuk pasien
        create_notification(
            recipient=booking.patient.user,
            title="Pengingat Appointment Besok",
            message=f"Anda memiliki appointment dengan Dr. {booking.doctor.full_name} besok ({booking.booking_date.strftime('%d %B %Y')}) pada pukul {booking.schedule.start_time if booking.schedule else 'waktu yang ditentukan'}.",
            notification_type='booking_reminder',
            booking=booking,
            action_url=reverse('booking:booking_detail', args=[booking.id])
        )

        # Pengingat untuk dokter
        create_notification(
            recipient=booking.doctor.user,
            title="Pengingat Appointment Besok",
            message=f"Anda memiliki appointment dengan {booking.patient.full_name} besok ({booking.booking_date.strftime('%d %B %Y')}) pada pukul {booking.schedule.start_time if booking.schedule else 'waktu yang ditentukan'}.",
            notification_type='booking_reminder',
            booking=booking,
            action_url=reverse(
                'booking:doctor_booking_detail', args=[booking.id])
        )


def get_unread_notifications_count(user):
    """
    Mendapatkan jumlah notifikasi yang belum dibaca untuk user
    """
    return Notification.objects.filter(recipient=user, is_read=False).count()


def mark_all_notifications_read(user):
    """
    Tandai semua notifikasi user sebagai sudah dibaca
    """
    Notification.objects.filter(
        recipient=user, is_read=False).update(is_read=True)
