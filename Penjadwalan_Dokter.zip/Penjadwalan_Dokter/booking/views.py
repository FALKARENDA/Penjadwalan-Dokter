from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.core.paginator import Paginator
from django.utils import timezone
from django import forms
from datetime import datetime, timedelta

from .models import Booking, BookingHistory, Notification
from .utils import create_booking_notification, get_unread_notifications_count
from dokter.models import DoctorProfile, Schedule, Specialization
from pasien.models import PatientProfile


class BookingForm(forms.ModelForm):
    booking_date = forms.DateField(
        widget=forms.DateInput(
            attrs={'type': 'date', 'min': timezone.now().date()}),
        help_text="Pilih tanggal konsultasi"
    )

    class Meta:
        model = Booking
        fields = ['doctor', 'schedule', 'booking_date', 'complaint', 'notes']
        widgets = {
            'complaint': forms.Textarea(attrs={'rows': 4, 'placeholder': 'Jelaskan keluhan Anda...'}),
            'notes': forms.Textarea(attrs={'rows': 3, 'placeholder': 'Catatan tambahan (opsional)'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['doctor'].queryset = DoctorProfile.objects.filter(
            is_available=True)
        self.fields['schedule'].queryset = Schedule.objects.filter(
            is_active=True, doctor__is_available=True)

    def clean_booking_date(self):
        booking_date = self.cleaned_data.get('booking_date')
        if booking_date and booking_date < timezone.now().date():
            raise forms.ValidationError(
                "Tanggal booking tidak boleh di masa lalu.")
        return booking_date


@login_required
def doctor_list_view(request):
    """Tampilkan daftar dokter dengan filter dan pencarian"""
    if request.user.role != 'pasien':
        messages.error(request, 'Akses ditolak. Anda bukan pasien.')
        return redirect('dashboard')

    # Get filter parameters
    specialization_id = request.GET.get('specialization')
    search = request.GET.get('search', '')
    sort_by = request.GET.get('sort', 'full_name')

    # Base queryset
    doctors = DoctorProfile.objects.filter(
        is_available=True).select_related('specialization', 'user')

    # Apply filters
    if specialization_id:
        doctors = doctors.filter(specialization_id=specialization_id)

    if search:
        doctors = doctors.filter(
            Q(full_name__icontains=search) |
            Q(specialization__name__icontains=search) |
            Q(bio__icontains=search)
        )

    # Apply sorting
    if sort_by == 'experience':
        doctors = doctors.order_by('-experience_years')
    elif sort_by == 'fee':
        doctors = doctors.order_by('consultation_fee')
    else:
        doctors = doctors.order_by('full_name')

    # Pagination
    paginator = Paginator(doctors, 6)  # 6 doctors per page
    page_number = request.GET.get('page')
    doctors_page = paginator.get_page(page_number)

    # Get all specializations for filter
    specializations = Specialization.objects.all().order_by('name')

    context = {
        'doctors': doctors_page,
        'specializations': specializations,
        'current_specialization': int(specialization_id) if specialization_id else None,
        'current_search': search,
        'current_sort': sort_by,
    }

    return render(request, 'booking/doctor_list.html', context)


@login_required
def create_booking_view(request, doctor_id=None):
    """Buat booking baru"""
    if request.user.role != 'pasien':
        messages.error(request, 'Akses ditolak. Anda bukan pasien.')
        return redirect('dashboard')

    try:
        patient_profile = PatientProfile.objects.get(user=request.user)
    except PatientProfile.DoesNotExist:
        messages.error(
            request, 'Profile pasien tidak ditemukan. Silakan lengkapi profile terlebih dahulu.')
        return redirect('patient_profile')

    # Get doctor if specified
    doctor = None
    if doctor_id:
        doctor = get_object_or_404(
            DoctorProfile, id=doctor_id, is_available=True)

    if request.method == 'POST':
        # Manual form processing untuk template custom
        doctor_id = request.POST.get('doctor')
        schedule_id = request.POST.get('schedule')
        appointment_date = request.POST.get('appointment_date')
        appointment_time = request.POST.get('appointment_time')
        complaint = request.POST.get('complaint')
        notes = request.POST.get('notes', '')

        # Debug: print semua POST data
        print(f"DEBUG: All POST data: {dict(request.POST)}")

        # Validasi data
        if not all([doctor_id, appointment_date, complaint]):
            missing_fields = []
            if not doctor_id:
                missing_fields.append('doctor')
            if not appointment_date:
                missing_fields.append('appointment_date')
            if not complaint:
                missing_fields.append('complaint')
            messages.error(
                request, f'Mohon lengkapi field: {", ".join(missing_fields)}')
            print(f"DEBUG: Missing fields: {missing_fields}")
            return render(request, 'booking/create_booking.html', {
                'selected_doctor': doctor,
                'doctors': DoctorProfile.objects.filter(is_available=True).select_related('specialization'),
                'today': timezone.now().date()
            })

        try:
            selected_doctor = DoctorProfile.objects.get(
                id=doctor_id, is_available=True)
            selected_schedule = None
            if schedule_id:
                selected_schedule = Schedule.objects.get(
                    id=schedule_id, doctor=selected_doctor)

            # Parse tanggal
            booking_date = datetime.strptime(
                appointment_date, '%Y-%m-%d').date()

            # Validasi tanggal tidak boleh masa lalu
            if booking_date < timezone.now().date():
                messages.error(
                    request, 'Tanggal booking tidak boleh di masa lalu.')
                return render(request, 'booking/create_booking.html', {
                    'selected_doctor': doctor,
                    'doctors': DoctorProfile.objects.filter(is_available=True).select_related('specialization'),
                    'today': timezone.now().date()
                })

            # Cek duplikasi booking
            existing_booking = Booking.objects.filter(
                patient=patient_profile,
                doctor=selected_doctor,
                booking_date=booking_date,
                status__in=['pending', 'confirmed']
            ).exists()

            if existing_booking:
                messages.error(
                    request, 'Anda sudah memiliki booking dengan dokter ini pada tanggal tersebut.')
                return render(request, 'booking/create_booking.html', {
                    'selected_doctor': doctor,
                    'doctors': DoctorProfile.objects.filter(is_available=True).select_related('specialization'),
                    'today': timezone.now().date()
                })

            # Buat booking baru
            booking = Booking.objects.create(
                patient=patient_profile,
                doctor=selected_doctor,
                schedule=selected_schedule,
                booking_date=booking_date,
                complaint=complaint,
                notes=notes,
                status='pending'
            )

            # Buat history entry
            BookingHistory.objects.create(
                booking=booking,
                old_status='',
                new_status='pending',
                changed_by=request.user,
                notes='Booking dibuat oleh pasien'
            )

            # Buat notifikasi
            create_booking_notification(booking, 'created')

            messages.success(
                request, f'Booking berhasil dibuat! ID Booking: #{booking.id}. Silakan tunggu konfirmasi dari dokter.')
            return redirect('booking:booking_success', booking_id=booking.id)

        except (DoctorProfile.DoesNotExist, Schedule.DoesNotExist, ValueError) as e:
            messages.error(request, f'Data tidak valid: {str(e)}')
            return render(request, 'booking/create_booking.html', {
                'selected_doctor': doctor,
                'doctors': DoctorProfile.objects.filter(is_available=True).select_related('specialization'),
                'today': timezone.now().date()
            })

    return render(request, 'booking/create_booking.html', {
        'selected_doctor': doctor,
        'doctors': DoctorProfile.objects.filter(is_available=True).select_related('specialization'),
        'today': timezone.now().date()
    })


@login_required
def booking_history_view(request):
    """Tampilkan riwayat booking pasien"""
    if request.user.role != 'pasien':
        messages.error(request, 'Akses ditolak. Anda bukan pasien.')
        return redirect('dashboard')

    try:
        patient_profile = PatientProfile.objects.get(user=request.user)
    except PatientProfile.DoesNotExist:
        messages.error(request, 'Profile pasien tidak ditemukan.')
        return redirect('patient_profile')

    # Get filter parameters
    status_filter = request.GET.get('status', '')

    # Base queryset
    bookings = Booking.objects.filter(patient=patient_profile).select_related(
        'doctor', 'doctor__specialization', 'schedule'
    ).order_by('-created_at')

    # Apply status filter
    if status_filter:
        bookings = bookings.filter(status=status_filter)

    # Pagination
    paginator = Paginator(bookings, 10)
    page_number = request.GET.get('page')
    bookings_page = paginator.get_page(page_number)

    context = {
        'bookings': bookings_page,
        'status_choices': Booking.STATUS_CHOICES,
        'current_status': status_filter,
    }

    return render(request, 'booking/booking_history.html', context)


@login_required
def cancel_booking_view(request, booking_id):
    """Batalkan booking"""
    if request.user.role != 'pasien':
        messages.error(request, 'Akses ditolak.')
        return redirect('dashboard')

    try:
        patient_profile = PatientProfile.objects.get(user=request.user)
        booking = get_object_or_404(
            Booking, id=booking_id, patient=patient_profile)

        if booking.status not in ['pending', 'confirmed']:
            messages.error(request, 'Booking tidak dapat dibatalkan.')
            return redirect('booking_history')

        # Cek apakah booking date sudah lewat
        if booking.booking_date < timezone.now().date():
            messages.error(
                request, 'Tidak dapat membatalkan booking yang sudah lewat.')
            return redirect('booking_history')

        # Simpan history
        BookingHistory.objects.create(
            booking=booking,
            old_status=booking.status,
            new_status='cancelled',
            changed_by=request.user,
            notes="Dibatalkan oleh pasien"
        )

        booking.status = 'cancelled'
        booking.save()

        # Buat notifikasi
        create_booking_notification(booking, 'cancelled', actor=request.user)

        messages.success(request, 'Booking berhasil dibatalkan.')

    except PatientProfile.DoesNotExist:
        messages.error(request, 'Profile pasien tidak ditemukan.')

    return redirect('booking_history')


@login_required
def doctor_detail_view(request, doctor_id):
    """Detail dokter dengan jadwal"""
    doctor = get_object_or_404(DoctorProfile, id=doctor_id, is_available=True)
    schedules = Schedule.objects.filter(
        doctor=doctor, is_active=True).order_by('weekday', 'start_time')

    # Get upcoming available dates (next 30 days)
    today = timezone.now().date()
    available_dates = []

    for i in range(30):
        check_date = today + timedelta(days=i)
        weekday = check_date.weekday()

        # Cek apakah ada jadwal pada hari ini
        if schedules.filter(weekday=weekday).exists():
            available_dates.append(check_date)

    context = {
        'doctor': doctor,
        'schedules': schedules,
        'available_dates': available_dates[:10],  # Show only first 10 dates
    }

    return render(request, 'booking/doctor_detail.html', context)


@login_required
def booking_success_view(request, booking_id):
    """Halaman sukses setelah booking"""
    try:
        booking = Booking.objects.get(
            id=booking_id, patient__user=request.user)
        return render(request, 'booking/booking_success.html', {'booking': booking})
    except Booking.DoesNotExist:
        messages.error(request, 'Booking tidak ditemukan.')
        return redirect('booking:booking_history')


@login_required
def booking_detail_view(request, booking_id):
    """Detail booking untuk pasien"""
    if request.user.role != 'pasien':
        messages.error(request, 'Akses ditolak. Anda bukan pasien.')
        return redirect('dashboard')

    try:
        patient_profile = PatientProfile.objects.get(user=request.user)
        booking = get_object_or_404(
            Booking,
            id=booking_id,
            patient=patient_profile
        )
    except PatientProfile.DoesNotExist:
        messages.error(request, 'Profile pasien tidak ditemukan.')
        return redirect('patient_profile')

    # Get booking history
    history = BookingHistory.objects.filter(
        booking=booking).order_by('-created_at')

    context = {
        'booking': booking,
        'history': history,
        'today': timezone.now().date(),
        'can_cancel': booking.status in ['pending', 'confirmed'] and booking.booking_date >= timezone.now().date(),
    }

    return render(request, 'booking/booking_detail.html', context)


@login_required
def doctor_booking_list_view(request):
    """Tampilkan daftar booking untuk dokter"""
    if request.user.role != 'dokter':
        messages.error(request, 'Akses ditolak. Anda bukan dokter.')
        return redirect('dashboard')

    try:
        doctor_profile = DoctorProfile.objects.get(user=request.user)
    except DoctorProfile.DoesNotExist:
        messages.error(request, 'Profile dokter tidak ditemukan.')
        return redirect('doctor_profile')

    # Get filter parameters
    status_filter = request.GET.get('status', '')
    date_from = request.GET.get('date_from', '')
    date_to = request.GET.get('date_to', '')

    # Base queryset - booking untuk dokter ini
    bookings = Booking.objects.filter(doctor=doctor_profile).select_related(
        'patient', 'patient__user', 'schedule'
    ).prefetch_related('history').order_by('-created_at')

    # Apply filters
    if status_filter:
        bookings = bookings.filter(status=status_filter)

    if date_from:
        try:
            date_from_parsed = datetime.strptime(date_from, '%Y-%m-%d').date()
            bookings = bookings.filter(booking_date__gte=date_from_parsed)
        except ValueError:
            pass

    if date_to:
        try:
            date_to_parsed = datetime.strptime(date_to, '%Y-%m-%d').date()
            bookings = bookings.filter(booking_date__lte=date_to_parsed)
        except ValueError:
            pass

    # Get statistics
    today = timezone.now().date()
    stats = {
        'total_bookings': bookings.count(),
        'pending_bookings': bookings.filter(status='pending').count(),
        'confirmed_bookings': bookings.filter(status='confirmed').count(),
        'today_bookings': bookings.filter(booking_date=today).count(),
        'upcoming_bookings': bookings.filter(
            booking_date__gte=today,
            status__in=['pending', 'confirmed']
        ).count(),
    }

    # Pagination
    paginator = Paginator(bookings, 10)
    page_number = request.GET.get('page')
    bookings_page = paginator.get_page(page_number)

    context = {
        'bookings': bookings_page,
        'status_choices': Booking.STATUS_CHOICES,
        'current_status': status_filter,
        'current_date_from': date_from,
        'current_date_to': date_to,
        'stats': stats,
        'doctor': doctor_profile,
    }

    return render(request, 'booking/doctor_booking_list.html', context)


@login_required
def doctor_booking_detail_view(request, booking_id):
    """Detail booking untuk dokter dengan opsi approve/reject"""
    if request.user.role != 'dokter':
        messages.error(request, 'Akses ditolak. Anda bukan dokter.')
        return redirect('dashboard')

    try:
        doctor_profile = DoctorProfile.objects.get(user=request.user)
        booking = get_object_or_404(
            Booking,
            id=booking_id,
            doctor=doctor_profile
        )
    except DoctorProfile.DoesNotExist:
        messages.error(request, 'Profile dokter tidak ditemukan.')
        return redirect('doctor_profile')

    if request.method == 'POST':
        action = request.POST.get('action')
        notes = request.POST.get('notes', '')

        old_status = booking.status

        if action == 'confirm' and booking.status == 'pending':
            booking.status = 'confirmed'
            booking.doctor_notes = notes
            booking.save()

            # Create history
            BookingHistory.objects.create(
                booking=booking,
                old_status=old_status,
                new_status='confirmed',
                changed_by=request.user,
                notes=f'Booking dikonfirmasi oleh dokter. {notes}' if notes else 'Booking dikonfirmasi oleh dokter.'
            )

            # Buat notifikasi
            create_booking_notification(
                booking, 'confirmed', actor=request.user, notes=notes)

            messages.success(request, 'Booking berhasil dikonfirmasi.')

        elif action == 'reject' and booking.status == 'pending':
            booking.status = 'rejected'
            booking.doctor_notes = notes
            booking.save()

            # Create history
            BookingHistory.objects.create(
                booking=booking,
                old_status=old_status,
                new_status='rejected',
                changed_by=request.user,
                notes=f'Booking ditolak oleh dokter. Alasan: {notes}' if notes else 'Booking ditolak oleh dokter.'
            )

            # Buat notifikasi
            create_booking_notification(
                booking, 'rejected', actor=request.user, notes=notes)

            messages.success(request, 'Booking berhasil ditolak.')

        elif action == 'complete' and booking.status == 'confirmed':
            booking.status = 'completed'
            booking.doctor_notes = notes
            booking.save()

            # Create history
            BookingHistory.objects.create(
                booking=booking,
                old_status=old_status,
                new_status='completed',
                changed_by=request.user,
                notes=f'Booking diselesaikan oleh dokter. {notes}' if notes else 'Booking diselesaikan oleh dokter.'
            )

            # Buat notifikasi
            create_booking_notification(
                booking, 'completed', actor=request.user, notes=notes)

            messages.success(request, 'Booking berhasil diselesaikan.')

        return redirect('booking:doctor_booking_detail', booking_id=booking.id)

    # Get booking history
    history = BookingHistory.objects.filter(
        booking=booking).order_by('-created_at')

    context = {
        'booking': booking,
        'history': history,
        'today': timezone.now().date(),
        'can_confirm': booking.status == 'pending',
        'can_reject': booking.status == 'pending',
        'can_complete': booking.status == 'confirmed',
    }

    return render(request, 'booking/doctor_booking_detail.html', context)


@login_required
def notification_list_view(request):
    """Tampilkan daftar notifikasi untuk user"""
    notifications = Notification.objects.filter(
        recipient=request.user
    ).order_by('-created_at')

    # Filter berdasarkan status read/unread jika ada
    status_filter = request.GET.get('status', '')
    if status_filter == 'unread':
        notifications = notifications.filter(is_read=False)
    elif status_filter == 'read':
        notifications = notifications.filter(is_read=True)

    # Pagination
    paginator = Paginator(notifications, 15)
    page_number = request.GET.get('page')
    notifications_page = paginator.get_page(page_number)

    # Stats
    unread_count = notifications.filter(is_read=False).count()
    total_count = notifications.count()

    context = {
        'notifications': notifications_page,
        'current_status': status_filter,
        'unread_count': unread_count,
        'total_count': total_count,
    }

    return render(request, 'booking/notification_list.html', context)


@login_required
def mark_notification_read(request, notification_id):
    """Mark notifikasi sebagai sudah dibaca"""
    try:
        notification = get_object_or_404(
            Notification,
            id=notification_id,
            recipient=request.user
        )
        notification.is_read = True
        notification.save()

        # Redirect ke action_url jika ada
        if notification.action_url:
            return redirect(notification.action_url)
        else:
            return redirect('booking:notification_list')

    except Notification.DoesNotExist:
        messages.error(request, 'Notifikasi tidak ditemukan.')
        return redirect('booking:notification_list')


@login_required
def mark_all_notifications_read(request):
    """Mark semua notifikasi sebagai sudah dibaca"""
    Notification.objects.filter(
        recipient=request.user,
        is_read=False
    ).update(is_read=True)

    messages.success(
        request, 'Semua notifikasi telah ditandai sebagai dibaca.')
    return redirect('booking:notification_list')


@login_required
def get_notification_count(request):
    """API endpoint untuk mendapatkan jumlah notifikasi yang belum dibaca"""
    from django.http import JsonResponse

    unread_count = get_unread_notifications_count(request.user)
    return JsonResponse({'unread_count': unread_count})
