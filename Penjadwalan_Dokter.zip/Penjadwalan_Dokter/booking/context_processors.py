from booking.utils import get_unread_notifications_count


def notification_count(request):
    """Context processor untuk menambahkan unread notification count ke semua template"""
    if request.user.is_authenticated:
        return {
            'unread_notification_count': get_unread_notifications_count(request.user)
        }
    return {
        'unread_notification_count': 0
    }
