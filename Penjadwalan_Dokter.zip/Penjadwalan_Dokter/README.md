# 🏥 Sistem Penjadwalan Dokter

Sistem manajemen penjadwalan dokter berbasis web yang memungkinkan pasien untuk membuat booking dengan dokter dan dokter untuk mengelola jadwal serta booking pasien. Dilengkapi dengan sistem notifikasi real-time dan dashboard interaktif.

## 🌟 Fitur Utama

### 👥 Multi-Role System
- **Admin**: Mengelola sistem secara keseluruhan
- **Dokter**: Mengelola jadwal, profil, dan booking pasien
- **Pasien**: Membuat booking, melihat riwayat, dan mengelola profil

### 📅 Sistem Booking
- Booking jadwal dengan dokter berdasarkan spesialisasi
- Konfirmasi, penolakan, dan penyelesaian booking oleh dokter
- Pembatalan booking oleh pasien
- Riwayat lengkap semua transaksi booking

### 🔔 Sistem Notifikasi Real-time
- Notifikasi otomatis untuk setiap perubahan status booking
- Badge notifikasi di navigation bar
- Halaman khusus untuk mengelola notifikasi
- Auto-refresh notification count setiap 30 detik

### 📊 Dashboard Interaktif
- Statistik real-time untuk dokter dan pasien
- Grafik aktivitas terbaru
- Quick actions untuk akses cepat fitur utama
- Card-based responsive design

### 🎨 User Interface
- Responsive design dengan Bootstrap 5
- Tema hijau-biru khas rumah sakit
- Font Awesome icons
- Animation dan hover effects

## 🚀 Teknologi yang Digunakan

- **Backend**: Django 5.1.4 (Python)
- **Database**: SQLite (development) / PostgreSQL (production ready)
- **Frontend**: Bootstrap 5, HTML5, CSS3, JavaScript
- **Icons**: Font Awesome
- **Authentication**: Django Auth System
- **Real-time Features**: AJAX untuk notification updates

## 📁 Struktur Project

```
Penjadwalan_Dokter/
├── accounts/               # App untuk authentication & user management
│   ├── models.py          # Custom User model dengan role system
│   ├── views.py           # Login, register, dashboard, profile views
│   └── templates/         # Templates untuk auth dan dashboard
├── booking/               # App utama untuk sistem booking
│   ├── models.py          # Booking, BookingHistory, Notification models
│   ├── views.py           # Views untuk booking dan notification
│   ├── utils.py           # Helper functions untuk notifikasi
│   ├── context_processors.py  # Global notification context
│   └── templates/         # Templates untuk booking dan notifikasi
├── dokter/                # App untuk manajemen dokter
│   ├── models.py          # DoctorProfile, Schedule, Specialization
│   └── admin.py           # Admin interface untuk dokter
├── pasien/                # App untuk manajemen pasien
│   ├── models.py          # PatientProfile model
│   └── admin.py           # Admin interface untuk pasien
├── templates/             # Global templates
│   ├── base.html          # Base template
│   └── accounts/          # Auth & dashboard templates
├── manage.py              # Django management script
├── requirements.txt       # Python dependencies
└── README.md             # Project documentation
```

## ⚙️ Cara Instalasi

### 1. Prerequisites
Pastikan sudah terinstall:
- Python 3.8 atau lebih baru
- pip (Python package manager)
- Git

### 2. Clone Repository
```bash
git clone <repository-url>
cd Penjadwalan_Dokter
```

### 3. Buat Virtual Environment
```bash
# Windows
python -m venv env
env\Scripts\activate

# Linux/Mac
python3 -m venv env
source env/bin/activate
```

### 4. Install Dependencies
```bash
pip install -r requirements.txt
```

### 5. Konfigurasi Database
```bash
# Jalankan migrasi database
python manage.py makemigrations
python manage.py migrate

# Buat superuser admin
python manage.py createsuperuser
```

### 6. Jalankan Server Development
```bash
python manage.py runserver
```

Akses aplikasi di `http://127.0.0.1:8000/`

## 🔧 Konfigurasi

### Environment Variables (Opsional)
Buat file `.env` di root directory:
```env
SECRET_KEY=your-secret-key-here
DEBUG=True
DATABASE_URL=sqlite:///db.sqlite3
```


## 👤 Penggunaan

### 1. Login sebagai Admin
- URL: `http://127.0.0.1:8000/admin/`
- Gunakan credentials superuser yang dibuat
- Username admin: admin, Pw: admin123
- Kelola specializations, initial data dokter

### 2. Registrasi User Baru
- URL: `http://127.0.0.1:8000/accounts/register/`
- Self register hanya untuk pasien, dokter harus melalui admin
- Lengkapi profil setelah registrasi

### 3. Workflow Dokter
1. Login dan lengkapi profil dokter
2. Atur jadwal praktek di "Jadwal Saya"
3. Terima/tolak booking dari pasien
4. Kelola booking di "Booking Pasien"
5. Monitor notifikasi untuk booking baru

### 4. Workflow Pasien
1. Login dan lengkapi profil pasien
2. Browse dokter berdasarkan spesialisasi
3. Buat booking dengan dokter pilihan
4. Monitor status booking di "Riwayat Booking"
5. Terima notifikasi untuk update status

## 🔔 Sistem Notifikasi

### Jenis Notifikasi
- **booking_created**: Booking baru dibuat pasien
- **booking_confirmed**: Booking dikonfirmasi dokter
- **booking_rejected**: Booking ditolak dokter
- **booking_cancelled**: Booking dibatalkan pasien
- **booking_completed**: Booking selesai
- **booking_reminder**: Pengingat booking (future feature)

### Fitur Notifikasi
- Real-time badge count di navigation
- Halaman dedicated untuk semua notifikasi
- Filter notifikasi (read/unread)
- Auto-redirect ke detail booking
- Mark all as read functionality

## 📱 Responsive Design

Aplikasi fully responsive dengan breakpoints:
- **Mobile**: < 768px
- **Tablet**: 768px - 1024px  
- **Desktop**: > 1024px

## 🎨 Tema & Styling

### Color Scheme
- **Primary**: #28a745 (Green)
- **Secondary**: #3235fcff (Blue)
- **Success**: #20c997 (Teal)
- **Warning**: #ffc107 (Yellow)
- **Danger**: #dc3545 (Red)

### Typography
- **Font**: System default (Arial, sans-serif)
- **Icons**: Font Awesome 6
- **Spacing**: Bootstrap 5 spacing system

## 🔒 Security Features

- CSRF Protection
- SQL Injection prevention via Django ORM
- XSS protection dengan Django template escaping
- Role-based access control
- Session management
- Password hashing dengan Django's built-in system

## 📊 Database Schema

### Key Models
- **User**: Custom user dengan role field
- **DoctorProfile**: Extended profile untuk dokter
- **PatientProfile**: Extended profile untuk pasien
- **Booking**: Core booking model dengan status tracking
- **BookingHistory**: Audit trail untuk perubahan booking
- **Notification**: Sistem notifikasi dengan targeting
- **Schedule**: Jadwal praktek dokter
- **Specialization**: Spesialisasi dokter

## 🚦 API Endpoints

### Authentication
- `GET/POST /accounts/login/` - Login
- `GET/POST /accounts/register/` - Register
- `POST /accounts/logout/` - Logout

### Booking
- `GET /booking/doctors/` - List dokter
- `GET/POST /booking/create/` - Create booking
- `GET /booking/history/` - Booking history
- `GET /booking/doctor/bookings/` - Doctor's bookings

### Notifications
- `GET /booking/notifications/` - List notifikasi
- `GET /booking/api/notification-count/` - Notification count API

## 🧪 Testing

### Manual Testing
1. Test registration flow
2. Test booking creation
3. Test doctor approval/rejection
4. Test notification system
5. Test responsive design

### Automated Testing (Future)
```bash
python manage.py test
```

## 🚀 Deployment

### Development
```bash
python manage.py runserver
```

### Production (contoh dengan Heroku)
1. Install Heroku CLI
2. Create Procfile: `web: gunicorn penjadwalan_dokter.wsgi`
3. Add PostgreSQL addon
4. Set environment variables
5. Deploy:
```bash
heroku create your-app-name
git push heroku main
heroku run python manage.py migrate
```

## 🐛 Troubleshooting

### Common Issues

**1. Migration Error**
```bash
python manage.py migrate --run-syncdb
```

**2. Static Files Not Loading**
```bash
python manage.py collectstatic
```

**3. Notification Table Missing**
```bash
python manage.py makemigrations booking
python manage.py migrate
```

**4. Import Error**
- Check virtual environment activated
- Reinstall requirements: `pip install -r requirements.txt`

## 🤝 Contributing

1. Fork repository
2. Create feature branch: `git checkout -b feature/new-feature`
3. Commit changes: `git commit -am 'Add new feature'`
4. Push branch: `git push origin feature/new-feature`
5. Submit Pull Request

## 📝 Changelog

### Version 1.0.0 (Current)
- ✅ Multi-role authentication system
- ✅ Complete booking workflow
- ✅ Real-time notification system
- ✅ Responsive dashboard
- ✅ Doctor schedule management
- ✅ Patient booking management
- ✅ Booking history and audit trail

### Future Features
- 📧 Email notifications
- 📱 Mobile app (React Native)
- 💳 Payment integration
- 📄 Medical records
- 🔍 Advanced search filters
- 📊 Analytics dashboard
- 🌐 Multi-language support

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Author

**Ilham Pangestu**
- GitHub: [Your GitHub Profile]
- Email: [Your Email]

## 📞 Support

Untuk pertanyaan dan dukungan:
- Create issue di GitHub repository
- Email: [support@yourproject.com]
- Documentation: [Link to detailed docs]

---

## 🎯 Quick Start Commands

```bash
# Setup project
git clone <repo-url>
cd Penjadwalan_Dokter
python -m venv env
env\Scripts\activate  # Windows
pip install -r requirements.txt

# Database setup
python manage.py makemigrations
python manage.py migrate
python manage.py createsuperuser

# Run development server
python manage.py runserver

# Access application
# http://127.0.0.1:8000/ - Main application
# http://127.0.0.1:8000/admin/ - Admin panel
```

**Happy Coding! 🚀**
